jQuery(function() {
      jQuery('.easy-slides').slidesjs({
        width: 940,
        height: 300,
        navigation: false,
      });
});
